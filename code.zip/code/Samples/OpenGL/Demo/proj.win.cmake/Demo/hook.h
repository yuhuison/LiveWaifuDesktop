#pragma once
#include "LAppDelegate.hpp"
#include <iostream>
#include "LAppView.hpp"
#include "LAppPal.hpp"
#include "LAppDefine.hpp"
#include "LAppLive2DManager.hpp"
#include "LAppTextureManager.hpp"
#include "hook.h"
LRESULT CALLBACK LowLevelMouseProc(INT nCode,
	WPARAM wParam,
	LPARAM lParam
);
BOOL UninstallHook();  //ж��  
void dragwindow();
BOOL InstallHook(HINSTANCE m_hInstance, HWND chwnd,LAppView* zview);     //��װ