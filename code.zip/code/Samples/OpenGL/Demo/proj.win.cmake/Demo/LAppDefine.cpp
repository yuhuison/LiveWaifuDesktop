﻿/*
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at http://live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

#include "LAppDefine.hpp"
#include <CubismFramework.hpp>

namespace LAppDefine {

    using namespace Csm;

    // 画面
    const csmFloat32 ViewMaxScale =1.0f;
    const csmFloat32 ViewMinScale = 1.0f;

    const csmFloat32 ViewLogicalLeft = -1.0f;
    const csmFloat32 ViewLogicalRight = 1.0f;

    const csmFloat32 ViewLogicalMaxLeft = -2.0f;
    const csmFloat32 ViewLogicalMaxRight = 2.0f;
    const csmFloat32 ViewLogicalMaxBottom = -2.0f;
    const csmFloat32 ViewLogicalMaxTop = 2.0f;

    // 相対パス
    const csmChar* ResourcesPath = "../../../../Res/";

    // モデルの後ろにある背景の画像ファイル
    const csmChar* BackImageName = "power.png";
    // 歯車
    const csmChar* GearImageName = "icon_gear.png";
    // 終了ボタン
    const csmChar* PowerImageName = "Close.png";

    // モデル定義------------------------------------------
    // モデルを配置したディレクトリ名の配列
    // ディレクトリ名とmodel3.jsonの名前を一致させておくこと
	const csmChar* ModelDir[] = {
		"dujiaoshou_4",
		"lafei",
		"lafei_4",
	};
   /* const csmChar* ModelDir[] = {
		"aidang_2",
		"aierdeliqi_4",
		"aimierbeierding_2",
		"banrenma_2",
		"beierfasite_2",
		"biaoqiang",
		"biaoqiang_3",
		"bisimai_2",
		"chuixue_3",
		"dafeng_2",
		"deyizhi_3",
		"dujiaoshou_4",
		"dunkeerke_2",
		"huangjiafangzhou_3",
		"huonululu_3",
		"huonululu_5",
		"kelifulan_3",
		"lafei",
		"lafei_4",
		"lingbo",
		"mingshi",
		"qibolin_2",
		"shengluyisi_2",
		"shengluyisi_3",
		"taiyuan_2",
		"tianlangxing_3",
		"tierbici_2",
		"xixuegui_4",
		"xuefeng",
		"yichui_2",
		"z23",
		"z46_2",
		"kurohatotyan",
		"DL008-3",
		"green",
		"MagicalGirl",
		
		"OnyayamiChan",
		"Hiyori",
        "Mark",
        "Natori"
    };*/
    const csmInt32 ModelDirSize = sizeof(ModelDir) / sizeof(const csmChar*);

    // 外部定義ファイル(json)と合わせる
    const csmChar* MotionGroupIdle = "Idle"; // アイドリング
    const csmChar* MotionGroupTapBody = "TapBody"; // 体をタップしたとき

    // 外部定義ファイル(json)と合わせる
    const csmChar* HitAreaNameHead = "Head";
    const csmChar* HitAreaNameBody = "Body";

    // モーションの優先度定数
    const csmInt32 PriorityNone = 0;
    const csmInt32 PriorityIdle = 1;
    const csmInt32 PriorityNormal = 2;
    const csmInt32 PriorityForce = 3;

    // デバッグ用ログの表示オプション
    const csmBool DebugLogEnable = true;
    const csmBool DebugTouchLogEnable = false;

    // Frameworkから出力するログのレベル設定
    const CubismFramework::Option::LogLevel CubismLoggingLevel = CubismFramework::Option::LogLevel_Verbose;

    // デフォルトのレンダーターゲットサイズ 
    const csmInt32 RenderTargetWidth = 1000;
    const csmInt32 RenderTargetHeight = 700;
}
