#include "hook.h"
#include <atlstr.h>

HHOOK mouse_Hook;
bool mouse_down = false;
bool drag_down = false;
HWND phwnd;
LAppView* tview;
BOOL InstallHook(HINSTANCE m_hInstance,HWND chwnd,LAppView* zview)
{
	
	if (mouse_Hook)   UninstallHook();
	mouse_Hook = SetWindowsHookEx(WH_MOUSE_LL,
		(HOOKPROC)(LowLevelMouseProc), m_hInstance, NULL);
	phwnd = chwnd;
	tview = zview;
	return(mouse_Hook != NULL);
	
}

BOOL UninstallHook()
{

	BOOL jud = FALSE;
	if (mouse_Hook) {
		jud = UnhookWindowsHookEx(mouse_Hook);
		mouse_Hook = NULL;  //set NULL  
	}

	return jud;
}

void dragwindow()
{
	drag_down=true;
}

LRESULT CALLBACK LowLevelMouseProc(INT nCode, WPARAM wParam, LPARAM lParam)
{
	POINT  _mousepoint;
	MSLLHOOKSTRUCT* pkbhs = (MSLLHOOKSTRUCT*)lParam;
	
	switch (nCode)
	{

	case HC_ACTION:
	{
		if (!(drag_down)) {
			//������  
			if (wParam == WM_LBUTTONDOWN || wParam == WM_MOUSEMOVE || wParam == WM_LBUTTONUP) {
				if (wParam == WM_LBUTTONDOWN) {
					GetCursorPos(&_mousepoint);
					RECT rect;
					GetWindowRect(phwnd, &rect);
					if (_mousepoint.x <= rect.right && _mousepoint.x >= rect.left) {
						if (_mousepoint.y >= rect.top && _mousepoint.y <= rect.bottom) {
							ScreenToClient(phwnd, &_mousepoint);
							if (mouse_down == false) {
								mouse_down = true;
								tview->OnTouchesBegan(_mousepoint.x, _mousepoint.y);
							}

						}
					}
				}
				if (wParam == WM_MOUSEMOVE) {
					GetCursorPos(&_mousepoint);
					RECT rect;
					GetWindowRect(phwnd, &rect);
					if (_mousepoint.x <= rect.right && _mousepoint.x >= rect.left) {
						if (_mousepoint.y >= rect.top && _mousepoint.y <= rect.bottom) {
							ScreenToClient(phwnd, &_mousepoint);
							tview->OnTouchesMoved(_mousepoint.x, _mousepoint.y);

						}
						else
						{
							if (mouse_down) {
								ScreenToClient(phwnd, &_mousepoint);
								mouse_down = false;
								tview->OnTouchesEnded(_mousepoint.x, _mousepoint.y);
							}

						}
					}
					else
					{
						if (mouse_down) {
							ScreenToClient(phwnd, &_mousepoint);
							mouse_down = false;
							tview->OnTouchesEnded(_mousepoint.x, _mousepoint.y);
						}
					}

				}

				if (wParam == WM_LBUTTONUP) {

					mouse_down = false;
					GetCursorPos(&_mousepoint);
					RECT rect;
					GetWindowRect(phwnd, &rect);
					ScreenToClient(phwnd, &_mousepoint);

					tview->OnTouchesEnded(_mousepoint.x, _mousepoint.y);

				}


			}
		}
		else
		{
			if (wParam == WM_MOUSEMOVE) {
				GetCursorPos(&_mousepoint);
				SetWindowPos(phwnd, HWND(-1), _mousepoint.x - 700, _mousepoint.y - 530, NULL, NULL, 1);
			}
			if (wParam == WM_LBUTTONUP) {
				GetCursorPos(&_mousepoint);
				SetWindowPos(phwnd, HWND(-1), _mousepoint.x-700, _mousepoint.y-530, NULL, NULL, 1);
				drag_down = false;
				mouse_down = false;
			}
		}
	}
	default:   break;
	}

	return CallNextHookEx(NULL, nCode, wParam, lParam);
}